package com.example.vkr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Spinner;

import com.example.vkr.ui.CinemaLocations;
import com.example.vkr.ui.CoordinatesServer;
import com.example.vkr.ui.ImageAdapter;
import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.UserInfo;
import com.example.vkr.ui.gallery.GalleryFragment;
import com.example.vkr.ui.gallery.MySpinnerAdapter;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

public class CreateLocationActivity extends AppCompatActivity {
    final ImageAdapter imageAdapter = new ImageAdapter(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_location);
        final Button addLoc = findViewById(R.id.create_loc_button);
        final EditText et = findViewById(R.id.locationNameEditText);
        final EditText et_adress = findViewById(R.id.addressEditText);
        final EditText coords = findViewById(R.id.coords_edit);
        final Spinner et_categories = findViewById(R.id.categorySpinner);
        MySpinnerAdapter myAdapter = new MySpinnerAdapter(this, 0,
                UserInfo.getInstance().getCategories_global());
        et_categories.setAdapter(myAdapter);
        final Button addPhoto = findViewById(R.id.addPictureButton);

        addPhoto.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //Вызываем стандартную галерею для выбора изображения с помощью Intent.ACTION_PICK:
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                //Тип получаемых объектов - image:
                photoPickerIntent.setType("image/*");
                //Запускаем переход с ожиданием обратного результата в виде информации об изображении:
                startActivityForResult(photoPickerIntent, 1);
            }
        });

        addLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CinemaLocations cl = new CinemaLocations(et.getText().toString(), UserInfo.getInstance().getName(), et_adress.getText().toString());
                ArrayList<Bitmap> imagies = new ArrayList<>();
                imagies.addAll(ImageAdapter.photos_locs);
                cl.setPhotos(imagies);
                ListLocations.addLoc(cl);
                try{
                    String[] cord = coords.getText().toString().split(",");
                    CoordinatesServer cs = new CoordinatesServer();
                    cs.setLat(Double.parseDouble(cord[0]));
                    cs.setLon(Double.parseDouble(cord[1]));
                    MapsFragment.markerChangeState.add(new MarkerOptions().position(new LatLng(Double.parseDouble(cord[0]), Double.parseDouble(cord[1]))).title(cl.getAddress()));
                }
                catch (Exception e)
                {
                    CoordinatesServer cs = new CoordinatesServer();
                    cs.setLat(55.72);
                    cs.setLon(36.62);
                    cl.setCoordinatesServer(cs);
                    MapsFragment.markerChangeState.add(new MarkerOptions().position(new LatLng(55.75,36.62)).title(cl.getAddress()));
                }
                ImageAdapter.photos_locs.clear();
                imageAdapter.notifyDataSetChanged();
                et.setText("");
                et_adress.setText("");
                GalleryFragment.stateAdapter.notifyDataSetChanged();
                Intent intent = new Intent(getApplicationContext(), MainMenuActivity.class);
                startActivity(intent);
            }
        });
        GridView gridview = findViewById(R.id.pictureGridView);
        gridview.setAdapter(imageAdapter);
        gridview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ImageAdapter.photos_locs.remove(position);
                //photos.remove(parent.getItemAtPosition(position));
                imageAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
        if(resultCode == RESULT_OK){
            try {
                //Получаем URI изображения, преобразуем его в Bitmap
                //объект и отображаем в элементе ImageView нашего интерфейса:
                final Uri imageUri = imageReturnedIntent.getData();
                final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                ImageAdapter.photos_locs.add(selectedImage);
                imageAdapter.notifyDataSetChanged();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

    }
}