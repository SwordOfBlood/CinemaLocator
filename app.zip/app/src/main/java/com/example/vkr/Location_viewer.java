package com.example.vkr;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vkr.ui.ImageAdapter;
import com.example.vkr.ui.LocationViewClass;
import com.example.vkr.ui.UserInfo;

import java.util.ArrayList;

public class Location_viewer extends AppCompatActivity {

    final ImageAdapter imageAdapter = new ImageAdapter(this);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_viewer);
        final TextView name = findViewById(R.id.viewlocationNameEditText);
        final TextView adress = findViewById(R.id.viewaddressEditText);
        final TextView coords = findViewById(R.id.viewcoords_edit);
        final TextView categories = findViewById(R.id.viewcategorySpinner);
        name.setText(LocationViewClass.getInstance().getName());
        adress.setText(LocationViewClass.getInstance().getAdress());
        coords.setText(LocationViewClass.getInstance().getCoords());
        categories.setText(LocationViewClass.getInstance().getManager());
        if (!LocationViewClass.getInstance().getPhotos().isEmpty()){
            ImageAdapter.photos_locs = LocationViewClass.getInstance().getPhotos();
        }
        else
            {
                ImageAdapter.photos_locs = new ArrayList<>();
            }
        GridView gridview = findViewById(R.id.viewpictureGridView);
        gridview.setAdapter(imageAdapter);
    }
}