package com.example.vkr;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.collection.ArraySet;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.vkr.ui.CinemaLocations;
import com.example.vkr.ui.CoordinatesServer;
import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.StateVO;
import com.example.vkr.ui.UserInfo;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;
import java.util.BitSet;

public class LoginFragment extends Fragment {

    public LoginFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View result=inflater.inflate(R.layout.fragment_login, container, false);
        Button login = result.findViewById(R.id.btn_login);
        final EditText login_text = result.findViewById(R.id.et_email);
        final EditText password = result.findViewById(R.id.et_password);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!login_text.getText().toString().isEmpty()&&!password.getText().toString().isEmpty()&&login_text.getText().toString().equals("pamashinistov@edu.hse.ru")){
                    UserInfo.getInstance().setEmail("pamashinistov@edu.hse.ru");
                    UserInfo.getInstance().setLogin(login_text.getText().toString());
                    UserInfo.getInstance().setName("Машинистов Павел Андреевич");
                    UserInfo.getInstance().setPassword(password.getText().toString());
                    UserInfo.getInstance().setPhone("+79200237785");
                    UserInfo.getInstance().setRole("Менеджер");
                    ListLocations.allLocs = (ArrayList<CinemaLocations>) Login_Activity.temp_locs;
                    if (ListLocations.getAllLocs().size()==0){
                        ListLocations.addLoc(new CinemaLocations("Парк Красногвардейские пруды", UserInfo.getInstance().getName(), "Россия, Москва, парк Красногвардейские пруды"));
                        ListLocations.addLoc(new CinemaLocations("Петровский парк", UserInfo.getInstance().getName(), "Ленинградский просп., 40, Москва"));
                        ListLocations.addLoc(new CinemaLocations("Музей Живая история", UserInfo.getInstance().getName(), "ул. Пречистенка, 33/19с1, Москва"));
                        ListLocations.addLoc(new CinemaLocations("Матвеевский лес", UserInfo.getInstance().getName(), "Россия, Москва, Матвеевский лес"));
                        ListLocations.addLoc(new CinemaLocations("Церковь Троицы Живоначальной в Старых Черёмушках", UserInfo.getInstance().getName(), "ул. Шверника, 17, корп. 1, Москва"));
                        ListLocations.addLoc(new CinemaLocations("Библиотека им. Абалкина", UserInfo.getInstance().getName(), "ул. Зацепа, 43, Москва"));
                        double[] lats = {55.76, 55.79, 55.74, 55.71, 55.69, 55.73};
                        double[] lons = {37.55, 37.56, 37.59, 37.48, 37.61, 37.63};
                        for (int i = 0; i<ListLocations.getAllLocs().size(); i++){
                            CoordinatesServer cs = new CoordinatesServer();
                            cs.setLat(lats[i]);
                            cs.setLon(lons[i]);
                            ListLocations.getAllLocs().get(i).setCoordinatesServer(cs);
                            MapsFragment.markerChangeState.add(new MarkerOptions().position(new LatLng(55.75,36.62)).title(ListLocations.getAllLocs().get(i).getAddress()));
                        }
                    }
                    else
                        {
                            for (int i = 0; i<ListLocations.getAllLocs().size(); i++)
                            {
                                MapsFragment.markerChangeState.add(new MarkerOptions().position(new LatLng(ListLocations.getAllLocs().get(i).getCoordinatesServer().getLat(),ListLocations.getAllLocs().get(i).getCoordinatesServer().getLon())).title(ListLocations.getAllLocs().get(i).getAddress()));
                                ArrayList<Bitmap> temp_photos = new ArrayList<>();
                                temp_photos.add(Login_Activity.temp_bitmaps.get(i*2));
                                temp_photos.add(Login_Activity.temp_bitmaps.get(i*2+1));
                                ListLocations.getAllLocs().get(i).setPhotos(temp_photos);
                            }
                        }
                    ListLocations.setRawLocs((ArrayList<CinemaLocations>) ListLocations.getAllLocs());
                    final ArraySet<String> select_qualification = new ArraySet<>();
                    for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                    {
                        select_qualification.add(ListLocations.getAllLocs().get(i).getName());
                    }
                    ArrayList<StateVO> listVOs = new ArrayList<>();
                    StateVO stateStart = new StateVO();
                    stateStart.setTitle("Выберите категории");
                    stateStart.setSelected(true);
                    listVOs.add(stateStart);
                    StateVO stateName = new StateVO();
                    stateName.setTitle(UserInfo.getInstance().getName());
                    stateName.setSelected(true);
                    if (UserInfo.getInstance().getRole().equals("Менеджер"))
                        listVOs.add(stateName);

                    for (int i = 0; i < select_qualification.size(); i++) {
                        StateVO stateVO = new StateVO();
                        stateVO.setTitle(select_qualification.valueAt(i));
                        stateVO.setSelected(true);
                        listVOs.add(stateVO);
                    }
                    UserInfo.getInstance().setCategories_global(listVOs);
                    Intent intent = new Intent(getContext(), MainMenuActivity.class);
                    startActivity(intent);
                }
                else
                    {
                        Toast toast1 = Toast.makeText(getContext(),
                                "Заполните все поля данных!", Toast.LENGTH_SHORT);
                        Toast toast2 = Toast.makeText(getContext(),
                                "Введите корректные логин и пароль!", Toast.LENGTH_SHORT);
                        if(!login_text.getText().toString().isEmpty()&&!password.getText().toString().isEmpty())
                            toast2.show();
                        else
                            toast1.show();
                    }

            }
        });
        // Inflate the layout for this fragment
        return result;
    }
}