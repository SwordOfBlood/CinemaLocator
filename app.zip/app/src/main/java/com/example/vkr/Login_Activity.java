package com.example.vkr;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.vkr.ui.CinemaLocations;
import com.example.vkr.ui.GetLocsApi;
import com.example.vkr.ui.ImageLoad;
import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.LocationViewClass;
import com.example.vkr.ui.ServerListLocs;
import com.example.vkr.ui.UserInfo;
import com.google.android.gms.common.api.internal.StatusExceptionMapper;
import com.google.gson.annotations.SerializedName;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Login_Activity extends AppCompatActivity {

    private static GetLocsApi locsApi;
    private Retrofit retrofit;
    public static ArrayList<Bitmap> temp_bitmaps = new ArrayList<>();
    @SerializedName("locations")
    public static List<CinemaLocations> temp_locs = new ArrayList<>();

    class AuthenticationPagerAdapter extends FragmentPagerAdapter {
        private ArrayList<Fragment> fragmentList = new ArrayList<>();

        public AuthenticationPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {
            return fragmentList.get(i);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        void addFragmet(Fragment fragment) {
            fragmentList.add(fragment);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_);
        new UserInfo();
        new LocationViewClass();

        ViewPager viewPager = findViewById(R.id.viewPager);
        final ImageView iv = findViewById(R.id.imageView3);
        AuthenticationPagerAdapter pagerAdapter = new AuthenticationPagerAdapter(getSupportFragmentManager());
        pagerAdapter.addFragmet(new LoginFragment());
        pagerAdapter.addFragmet(new RegistryFragment());
        viewPager.setAdapter(pagerAdapter);
        retrofit = new Retrofit.Builder()
                .baseUrl("https://cinemalocations.ru") //Базовая часть адреса
                .addConverterFactory(GsonConverterFactory.create()) //Конвертер, необходимый для преобразования JSON'а в объекты
                .build();
        locsApi = retrofit.create(GetLocsApi.class);

        getApi().getLocations().enqueue(new Callback<ServerListLocs>() {
            @Override
            public void onResponse(Call<ServerListLocs> call, Response<ServerListLocs> response) {
                if (response.body() != null) {
                    ServerListLocs serverListLocs = response.body();
                    temp_locs = serverListLocs.getLocs();
                    for (int i = 0; i < temp_locs.size(); i++)
                    {
                        for (int j = 0; j < temp_locs.get(i).getImages().size(); j++)
                        {
                            ImageLoad im = new ImageLoad(temp_locs.get(i).getImages().get(j).getUrl(), iv);
                            im.execute();
                        }
                    }
                }
            }

            @Override
            public void onFailure(Call<ServerListLocs> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "An error occurred during networking", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //Обрабатываем результат выбора в галерее:
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent imageReturnedIntent) {
        super.onActivityResult(requestCode, resultCode, imageReturnedIntent);
                if(resultCode == RESULT_OK){
                    try {
                        //Получаем URI изображения, преобразуем его в Bitmap
                        //объект и отображаем в элементе ImageView нашего интерфейса:
                        final Uri imageUri = imageReturnedIntent.getData();
                        final InputStream imageStream = getContentResolver().openInputStream(imageUri);
                        final Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
                        final ImageView avatar = findViewById(R.id.avatar_reg);
                        avatar.setImageBitmap(selectedImage);
                        UserInfo.getInstance().setImage(selectedImage);
                        Toast toast = Toast.makeText(this,"Изображение загружено", Toast.LENGTH_SHORT);
                        toast.show();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    }
                }

    }
    public static GetLocsApi getApi() {
        return locsApi;
    }
}