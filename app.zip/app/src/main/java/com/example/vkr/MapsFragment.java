package com.example.vkr;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.LocationViewClass;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;

public class MapsFragment extends Fragment {

    public static ArrayList<MarkerOptions> markerChangeState = new ArrayList<>();
    private OnMapReadyCallback callback = new OnMapReadyCallback() {

        /**
         * Manipulates the map once available.
         * This callback is triggered when the map is ready to be used.
         * This is where we can add markers or lines, add listeners or move the camera.
         * In this case, we just add a marker near Sydney, Australia.
         * If Google Play services is not installed on the device, the user will be prompted to
         * install it inside the SupportMapFragment. This method will only be triggered once the
         * user has installed Google Play services and returned to the app.
         */
        @Override
        public void onMapReady(GoogleMap googleMap) {
            LatLng sydney = new LatLng(55.751999, 37.617734);
            for (int i = 0; i < markerChangeState.size(); i++)
            {
                googleMap.addMarker(markerChangeState.get(i));
            }
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(markerChangeState.get(0).getPosition())
                    .zoom(10)
                    .build();
            googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(Marker marker) {
                    for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                    {
                        if(ListLocations.getAllLocs().get(i).getAddress().equals(marker.getTitle()))
                        {
                            LocationViewClass.getInstance().setAdress(ListLocations.getAllLocs().get(i).getAddress());
                            LocationViewClass.getInstance().setName(ListLocations.getAllLocs().get(i).getName());
                            LocationViewClass.getInstance().setManager(ListLocations.getAllLocs().get(i).getManager());
                            LocationViewClass.getInstance().setCoords(ListLocations.getAllLocs().get(i).getCoordinatesServer().getLat()+" "+ListLocations.getAllLocs().get(i).getCoordinatesServer().getLon());
                            LocationViewClass.getInstance().setPhotos(ListLocations.getAllLocs().get(i).getPhotos());
                            LocationViewClass.getInstance().setImages(ListLocations.getAllLocs().get(i).getImages());
                            Intent intent = new Intent(getContext(), Location_viewer.class);
                            startActivity(intent);
                        }
                    }
                    return false;
                }
            });
            googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_maps, container, false);
        /*SearchView searchView = root.findViewById(R.id.searchView4);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<CinemaLocations> temp_list = new ArrayList<>();
                for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                {
                    if (ListLocations.getAllLocs().get(i).getName().toLowerCase().contains(newText.toLowerCase()))
                        temp_list.add(ListLocations.getAllLocs().get(i));
                }
                ListLocations.setRawLocs(temp_list);
                if (ListLocations.getRawLocs().size()>1)
                {
                    markerChangeState.get(5).visible(false);
                }
                else
                    {
                        markerChangeState.get(0).visible(false);
                        markerChangeState.get(1).visible(false);
                        markerChangeState.get(2).visible(false);
                        markerChangeState.get(4).visible(false);
                    }
                return true;
            }
        });*/
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }
}