package com.example.vkr;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.collection.ArraySet;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.vkr.ui.CinemaLocations;
import com.example.vkr.ui.CoordinatesServer;
import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.StateVO;
import com.example.vkr.ui.UserInfo;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.ArrayList;


public class RegistryFragment extends Fragment {

    private final int Pick_image = 1;

    public RegistryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View result=inflater.inflate(R.layout.fragment_registry, container, false);
        //Связываемся с нашим ImageView:
        final EditText login_text = result.findViewById(R.id.et_email_reg);
        final EditText password = result.findViewById(R.id.et_password_reg);
        final EditText name = result.findViewById(R.id.et_name);
        final EditText repass = result.findViewById(R.id.et_repassword);
        final EditText phone = result.findViewById(R.id.phone);
        final Spinner role_spin = result.findViewById(R.id.reg_role);
        final Toast toast1 = Toast.makeText(getContext(),
                "Пароли не совпадают", Toast.LENGTH_SHORT);
        final Toast toast2 = Toast.makeText(getContext(),
                "Заполните все поля данных!", Toast.LENGTH_SHORT);
        Button reg = result.findViewById(R.id.btn_register);
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!login_text.getText().toString().isEmpty()&&!password.getText().toString().isEmpty()&&!name.getText().toString().isEmpty()&&!repass.getText().toString().isEmpty()&&!phone.getText().toString().isEmpty())
                {
                    if (!password.getText().toString().equals(repass.getText().toString()))
                        toast1.show();
                    else
                        {
                            UserInfo.getInstance().setEmail(login_text.getText().toString());
                            UserInfo.getInstance().setLogin(login_text.getText().toString());
                            UserInfo.getInstance().setName(name.getText().toString());
                            UserInfo.getInstance().setPassword(password.getText().toString());
                            UserInfo.getInstance().setPhone(phone.getText().toString());
                            UserInfo.getInstance().setRole(role_spin.getSelectedItem().toString());
                            ListLocations.allLocs = (ArrayList<CinemaLocations>) Login_Activity.temp_locs;
                            if (ListLocations.getAllLocs().size()==0){
                                ListLocations.addLoc(new CinemaLocations("Парк Красногвардейские пруды", UserInfo.getInstance().getName(), "Россия, Москва, парк Красногвардейские пруды"));
                                ListLocations.addLoc(new CinemaLocations("Петровский парк", UserInfo.getInstance().getName(), "Ленинградский просп., 40, Москва"));
                                ListLocations.addLoc(new CinemaLocations("Музей Живая история", UserInfo.getInstance().getName(), "ул. Пречистенка, 33/19с1, Москва"));
                                ListLocations.addLoc(new CinemaLocations("Матвеевский лес", UserInfo.getInstance().getName(), "Россия, Москва, Матвеевский лес"));
                                ListLocations.addLoc(new CinemaLocations("Церковь Троицы Живоначальной в Старых Черёмушках", UserInfo.getInstance().getName(), "ул. Шверника, 17, корп. 1, Москва"));
                                ListLocations.addLoc(new CinemaLocations("Библиотека им. Абалкина", UserInfo.getInstance().getName(), "ул. Зацепа, 43, Москва"));
                                double[] lats = {55.76, 55.79, 55.74, 55.71, 55.69, 55.73};
                                double[] lons = {37.55, 37.56, 37.59, 37.48, 37.61, 37.63};
                                for (int i = 0; i<ListLocations.getAllLocs().size(); i++){
                                    CoordinatesServer cs = new CoordinatesServer();
                                    cs.setLat(lats[i]);
                                    cs.setLon(lons[i]);
                                    ListLocations.getAllLocs().get(i).setCoordinatesServer(cs);
                                    MapsFragment.markerChangeState.add(new MarkerOptions().position(new LatLng(55.75,36.62)).title(ListLocations.getAllLocs().get(i).getAddress()));
                                }
                            }
                            else
                            {
                                for (int i = 0; i<ListLocations.getAllLocs().size(); i++)
                                {
                                    MapsFragment.markerChangeState.add(new MarkerOptions().position(new LatLng(ListLocations.getAllLocs().get(i).getCoordinatesServer().getLat(),ListLocations.getAllLocs().get(i).getCoordinatesServer().getLon())).title(ListLocations.getAllLocs().get(i).getAddress()));
                                    ArrayList<Bitmap> temp_photos = new ArrayList<>();
                                    temp_photos.add(Login_Activity.temp_bitmaps.get(i*2));
                                    temp_photos.add(Login_Activity.temp_bitmaps.get(i*2+1));
                                    ListLocations.getAllLocs().get(i).setPhotos(temp_photos);
                                }
                            }
                            ListLocations.setRawLocs((ArrayList<CinemaLocations>) ListLocations.getAllLocs());
                            final ArraySet<String> select_qualification = new ArraySet<>();
                            for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                            {
                                select_qualification.add(ListLocations.getAllLocs().get(i).getName());
                            }
                            ArrayList<StateVO> listVOs = new ArrayList<>();
                            StateVO stateStart = new StateVO();
                            stateStart.setTitle("Выберите категории");
                            stateStart.setSelected(true);
                            listVOs.add(stateStart);
                            StateVO stateName = new StateVO();
                            stateName.setTitle(UserInfo.getInstance().getName());
                            stateName.setSelected(true);
                            if (UserInfo.getInstance().getRole().equals("Менеджер"))
                                listVOs.add(stateName);

                            for (int i = 0; i < select_qualification.size(); i++) {
                                StateVO stateVO = new StateVO();
                                stateVO.setTitle(select_qualification.valueAt(i));
                                stateVO.setSelected(true);
                                listVOs.add(stateVO);
                            }
                            UserInfo.getInstance().setCategories_global(listVOs);
                        Intent intent = new Intent(getContext(), MainMenuActivity.class);
                        startActivity(intent);
                    }
                }
                else
                    toast2.show();
            }
        });
        //Связываемся с нашей кнопкой Button:
        Button PickImage = result.findViewById(R.id.button);
        //Настраиваем для нее обработчик нажатий OnClickListener:
        PickImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                //Вызываем стандартную галерею для выбора изображения с помощью Intent.ACTION_PICK:
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                //Тип получаемых объектов - image:
                photoPickerIntent.setType("image/*");
                //Запускаем переход с ожиданием обратного результата в виде информации об изображении:
                startActivityForResult(photoPickerIntent, Pick_image);
            }
        });
        return result;
    }

    @Override
    public void onResume() {
        super.onResume();

    }
}