package com.example.vkr.ui;

import android.graphics.Bitmap;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import retrofit2.http.Url;

public class CinemaLocations
{

    public CinemaLocations(String name, String manager, String address)
    {
        this.name = name;
        this.manager = manager;
        this.address = address;
    }
    @SerializedName("description")
    @Expose
    private String name;
    @SerializedName("name")
    @Expose
    private String manager;
    @SerializedName("address")
    @Expose
    private String address;

    @SerializedName("tags")
    @Expose
    private ArrayList<String> categories = new ArrayList<>();

    private ArrayList<Bitmap> photos = new ArrayList<>();
    @SerializedName("coordinates")
    @Expose
    private CoordinatesServer coordinatesServer;

    @SerializedName("images")
    @Expose
    private ArrayList<ImageServer> images = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<Bitmap> getPhotos() {
        return photos;
    }

    public void setPhotos(ArrayList<Bitmap> photos) {
        this.photos = photos;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<String> categories) {
        this.categories = categories;
    }

    public CoordinatesServer getCoordinatesServer() {
        return coordinatesServer;
    }

    public void setCoordinatesServer(CoordinatesServer coordinatesServer) {
        this.coordinatesServer = coordinatesServer;
    }

    public ArrayList<ImageServer> getImages() {
        return images;
    }

    public void setImages(ArrayList<ImageServer> images) {
        this.images = images;
    }
}
