package com.example.vkr.ui;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface GetLocsApi {
    @GET("/api/locationsUnauth?pageNumber=1&pageSize=10")
    Call<ServerListLocs> getLocations();
}
