package com.example.vkr.ui;

import java.util.ArrayList;
import java.util.List;

public class ListLocations {

    public static ArrayList<CinemaLocations> allLocs = new ArrayList<>();
    private static ArrayList<CinemaLocations> rawLocs = new ArrayList<>();

    public static List<CinemaLocations> getAllLocs() {
        return allLocs;
    }

    public static void setRawLocs(ArrayList<CinemaLocations> rawLocs) {
        ListLocations.rawLocs = rawLocs;
    }

    public static List<CinemaLocations> getRawLocs()
    {
        return rawLocs;
    }

    public static void addLoc(CinemaLocations cl)
    {
        allLocs.add(cl);
    }
}
