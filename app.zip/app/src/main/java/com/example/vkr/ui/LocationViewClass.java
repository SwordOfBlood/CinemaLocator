package com.example.vkr.ui;

import android.graphics.Bitmap;

import java.util.ArrayList;
import java.util.List;

public class LocationViewClass {
    private static LocationViewClass instance;
    public static LocationViewClass getInstance(){ // #3
        if(instance == null){		//если объект еще не создан
            instance = new LocationViewClass();	//создать новый объект
        }
        return instance;		// вернуть ранее созданный объект
    }

    private String name;
    private String manager;
    private String adress;
    private String coords;
    private CoordinatesServer coordinatesServer;
    private ArrayList<String> categories = new ArrayList<>();
    private ArrayList<Bitmap> photos = new ArrayList<>();
    private ArrayList<ImageServer> images = new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getCoords() {
        return coords;
    }

    public void setCoords(String coords) {
        this.coords = coords;
    }

    public ArrayList<Bitmap> getPhotos() {
        return photos;
    }

    public void setPhotos(ArrayList<Bitmap> photos) {
        this.photos = photos;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(ArrayList<String> categories) {
        this.categories = categories;
    }

    public CoordinatesServer getCoordinatesServer() {
        return coordinatesServer;
    }

    public void setCoordinatesServer(CoordinatesServer coordinatesServer) {
        this.coordinatesServer = coordinatesServer;
    }

    public ArrayList<ImageServer> getImages() {
        return images;
    }

    public void setImages(ArrayList<ImageServer> images) {
        this.images = images;
    }
}
