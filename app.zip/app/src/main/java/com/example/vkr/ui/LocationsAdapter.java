package com.example.vkr.ui;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.vkr.R;

import java.util.ArrayList;
import java.util.List;

public class LocationsAdapter extends ArrayAdapter<CinemaLocations> {

    private LayoutInflater inflater;
    private int layout;
    public static List<CinemaLocations> cinemaLocations = new ArrayList<>();

    public LocationsAdapter(Context context, int resource, List<CinemaLocations> states) {
        super(context, resource, states);
        cinemaLocations = ListLocations.getRawLocs();
        this.layout = resource;
        this.inflater = LayoutInflater.from(context);
    }
    public View getView(int position, View convertView, ViewGroup parent) {

        @SuppressLint("ViewHolder") View view = inflater.inflate(this.layout, parent, false);

        ImageView photo_loc = view.findViewById(R.id.photo_loc);
        TextView name_loc = view.findViewById(R.id.loc_name);
        TextView adress_loc = view.findViewById(R.id.adress_loc);
        CinemaLocations state;

        if (ListLocations.getRawLocs().contains(cinemaLocations.get(position)))
        {
            state = cinemaLocations.get(position);

            if (state.getImages().isEmpty()&&state.getPhotos().isEmpty())
                photo_loc.setImageResource(R.drawable.ic_menu_camera);
            else if (!state.getPhotos().isEmpty())
            {
                photo_loc.setImageBitmap(state.getPhotos().get(0));
            }
            else{
                ImageLoad im = new ImageLoad(state.getImages().get(0).getUrl(), photo_loc);
                im.execute();
            }
            name_loc.setText(state.getName());
            adress_loc.setText(state.getAddress());
        }
        else
            {
                name_loc.setText("");
                adress_loc.setText("");
            }

        return view;
    }
}