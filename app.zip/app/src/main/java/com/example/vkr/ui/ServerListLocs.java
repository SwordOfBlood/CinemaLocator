package com.example.vkr.ui;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ServerListLocs {
    @SerializedName("locations")
    @Expose
    private List<CinemaLocations> locs = null;

    public List<CinemaLocations> getLocs() {
        return locs;
    }

    public void setLocs(List<CinemaLocations> locs) {
        this.locs = locs;
    }
}
