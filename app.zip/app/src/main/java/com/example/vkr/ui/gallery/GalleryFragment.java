package com.example.vkr.ui.gallery;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.vkr.Location_viewer;
import com.example.vkr.R;
import com.example.vkr.ui.CinemaLocations;
import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.LocationViewClass;
import com.example.vkr.ui.LocationsAdapter;

import java.util.ArrayList;

public class GalleryFragment extends Fragment {

    public static LocationsAdapter stateAdapter;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);
        final ListView cinemas = root.findViewById(R.id.cinemas);

        stateAdapter = new LocationsAdapter(getContext(), R.layout.list_item, ListLocations.getRawLocs());
        cinemas.setAdapter(stateAdapter);
        stateAdapter.notifyDataSetChanged();
        AdapterView.OnItemClickListener itemListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
            {
                CinemaLocations cl = (CinemaLocations)parent.getItemAtPosition(position);
                LocationViewClass.getInstance().setAdress(cl.getAddress());
                LocationViewClass.getInstance().setName(cl.getName());
                LocationViewClass.getInstance().setManager(cl.getManager());
                LocationViewClass.getInstance().setCoords(cl.getCoordinatesServer().getLat()+" "+cl.getCoordinatesServer().getLon());
                LocationViewClass.getInstance().setPhotos(cl.getPhotos());
                LocationViewClass.getInstance().setImages(cl.getImages());
                Intent intent = new Intent(getContext(), Location_viewer.class);
                startActivity(intent);
            }
        };
        cinemas.setOnItemClickListener(itemListener);

        SearchView searchView = root.findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<CinemaLocations> temp_list = new ArrayList<>();
                for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                {
                    if (ListLocations.getAllLocs().get(i).getName().toLowerCase().contains(newText.toLowerCase()))
                        temp_list.add(ListLocations.getAllLocs().get(i));
                }
                ListLocations.setRawLocs(temp_list);
                ArrayList<CinemaLocations> temp_list2 = new ArrayList<>(temp_list);
                for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                {
                    if (!ListLocations.getAllLocs().get(i).getName().toLowerCase().contains(newText.toLowerCase()))
                        temp_list2.add(ListLocations.getAllLocs().get(i));
                }
                LocationsAdapter.cinemaLocations = temp_list2;
                stateAdapter.notifyDataSetChanged();
                return true;
            }
        });
        return root;
    }
}