package com.example.vkr.ui.home;

import android.content.Intent;
import android.icu.text.UnicodeSet;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.vkr.CreateLocationActivity;
import com.example.vkr.MainMenuActivity;
import com.example.vkr.R;
import com.example.vkr.ui.ImageAdapter;
import com.example.vkr.ui.UserInfo;

public class HomeFragment extends Fragment {


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView login_text = root.findViewById(R.id.prof_email);
        final TextView name = root.findViewById(R.id.prof_name);
        final TextView role = root.findViewById(R.id.prof_role);
        final TextView phone = root.findViewById(R.id.prof_phone);
        final ImageView avatar_prof = root.findViewById(R.id.imageView2);
        login_text.setText(UserInfo.getInstance().getEmail());
        name.setText(UserInfo.getInstance().getName());
        role.setText(UserInfo.getInstance().getRole());
        phone.setText(UserInfo.getInstance().getPhone());
        avatar_prof.setImageBitmap(UserInfo.getInstance().getImage());
        final EditText name_ed = root.findViewById(R.id.et_name_prof);
        final EditText email_ed = root.findViewById(R.id.et_email_prof);
        final EditText phone_ed = root.findViewById(R.id.et_phone_prof);
        final Button edit = root.findViewById(R.id.edit_prof);
        final Button create = root.findViewById(R.id.create_loc);
        if (UserInfo.getInstance().getRole().equals("Менеджер"))
        {
            create.setVisibility(View.VISIBLE);
        }
        else
            {
                create.setVisibility(View.INVISIBLE);
            }
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name_ed.getVisibility()==View.INVISIBLE){
                    edit.setText("Сохранить изменения");
                    name_ed.setVisibility(View.VISIBLE);
                    email_ed.setVisibility(View.VISIBLE);
                    phone_ed.setVisibility(View.VISIBLE);
                    login_text.setVisibility(View.INVISIBLE);
                    name.setVisibility(View.INVISIBLE);
                    phone.setVisibility(View.INVISIBLE);
                    create.setVisibility(View.INVISIBLE);
                }
                else
                    {
                        edit.setText("Редактировать аккаунт");
                        name_ed.setVisibility(View.INVISIBLE);
                        email_ed.setVisibility(View.INVISIBLE);
                        phone_ed.setVisibility(View.INVISIBLE);
                        if (!name_ed.getText().toString().isEmpty())
                            UserInfo.getInstance().setName(name_ed.getText().toString());
                        if (!email_ed.getText().toString().isEmpty())
                            UserInfo.getInstance().setEmail(email_ed.getText().toString());
                        if (!phone_ed.getText().toString().isEmpty())
                            UserInfo.getInstance().setPhone(phone_ed.getText().toString());
                        login_text.setText(UserInfo.getInstance().getEmail());
                        name.setText(UserInfo.getInstance().getName());
                        phone.setText(UserInfo.getInstance().getPhone());
                        login_text.setVisibility(View.VISIBLE);
                        name.setVisibility(View.VISIBLE);
                        phone.setVisibility(View.VISIBLE);
                        if (UserInfo.getInstance().getRole().equals("Менеджер"))
                        {
                            create.setVisibility(View.VISIBLE);
                        }
                    }
            }
        });

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ImageAdapter.photos_locs.clear();
                Intent intent = new Intent(getContext(), CreateLocationActivity.class);
                startActivity(intent);
            }
        });
        return root;
    }
}