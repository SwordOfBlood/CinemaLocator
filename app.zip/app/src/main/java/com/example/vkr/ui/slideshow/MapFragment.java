package com.example.vkr.ui.slideshow;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.vkr.ui.CinemaLocations;
import com.example.vkr.ui.ListLocations;
import com.example.vkr.ui.LocationsAdapter;
import com.example.vkr.ui.UserInfo;
import com.example.vkr.ui.gallery.MySpinnerAdapter;
import com.google.android.gms.maps.*;

import com.example.vkr.R;

import java.util.ArrayList;

public class MapFragment extends Fragment {

    public MapFragment() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_map, container, false);
        SearchView searchView = root.findViewById(R.id.searchView3);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<CinemaLocations> temp_list = new ArrayList<>();
                for (int i = 0; i < ListLocations.getAllLocs().size(); i++)
                {
                    if (ListLocations.getAllLocs().get(i).getName().toLowerCase().contains(newText.toLowerCase()))
                        temp_list.add(ListLocations.getAllLocs().get(i));
                }
                ListLocations.setRawLocs(temp_list);
                return true;
            }
        });

        return root;
    }
}